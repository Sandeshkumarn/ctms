# CRICKET TOURNAMENT ORGANIZER

A simple project on DBMS built using Django(MySQL) to organize cricket tournaments.


## Features

- Total control of the tournaments using Admin Panel
- Team Manager Dashboard
- Schedule, track and store statistics of every match
- Track player statistics


